function Dialog() {

}

Dialog.alert = function (msg, title, okcallback) {
    var template = '<div id="wkfsdialogalert" class="modal fade" role="dialog">'
                        + '<div class="modal-dialog alert-modal">'
                            + '<div class="modal-content">'
                                + '<div class="modal-header">'
                                    + '<button type="button" class="close dialog-close" data-dismiss="modal">&times;</button>'
                                    + '<h4 class="modal-title">' + (typeof title === 'undefined' ? 'Alert' : title) + '</h4>'
                                + '</div>'
                                + '<div class="modal-body alert-modal-body">'
                                    + '<div class="col-md-1 pull-left">'
                                        +'<i class="fa fa-warning-circle fa-3x blue-icon"></i>'
                                    + '</div>'
                                    + '<div class="col-md-10 pull-right">' + (typeof msg === 'undefined' ? '' : msg) + '</div>'
                                    + '<br />'
                                + '</div>'
                              
                                + '<div class="modal-footer alert-modal-body">'
                                    +  '<div class="pull-right">'
                                         + '<button type="button" id="btnwkfsdialogalertok" class="btn btn-default" data-dismiss="modal">OK</button>'
                                    + '</div>'
                               + '</div>'
                            + '</div>'
                        + '</div>'
                    + '</div>';

    $(template).appendTo(document.body);
    var dialog = $('#wkfsdialogalert');
    if (okcallback != undefined && okcallback != null) {
        $("#btnwkfsdialogalertok").on('click', function () {
            dialog.modal('hide');
            okcallback();
        });
    }
    dialog.modal('show').on('hidden.bs.modal', function () {
        $(this).remove();
    });
}
     

Dialog.confirm = function (msg, yesCallback, noCallback, title) {
    var template = '<div id="wkfsdialogconfirm" class="modal fade" role="dialog">'
                        + '<div class="modal-dialog">'
                            + '<div class="modal-content">'
                                + '<div class="modal-header dialog-confirm-modal-header">'
                                    + '<button type="button" class="close" data-dismiss="modal">&times;</button>'
                                    + '<h4>' + (typeof title === 'undefined' ? 'Confirm' : title) + '</h4>'
                                + '</div>'
                                + '<div class="modal-body">'
                                    + '<p>' + (typeof msg === 'undefined' ? '' : msg) + '</p>'
                                + '</div>'
                                + '<div class="modal-footer">'
                                    + '<button type="button" id="btnwkfsdialogconfirmno" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i>&nbsp;No</button>'
                                    + '<button type="button" id="btnwkfsdialogconfirmyes" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-check"></i>&nbsp;Yes</button>'
                                + '</div>'
                            + '</div>'
                        + '</div>'
                    + '</div>';

    $(template).appendTo(document.body);
    var dialog = $('#wkfsdialogconfirm');
    if (yesCallback != undefined && yesCallback != null) {
        $("#btnwkfsdialogconfirmyes").on('click', function () {
            dialog.modal('hide');
            yesCallback();
        });
    }

    if (noCallback != undefined && noCallback != null) {
        $("#btnwkfsdialogconfirmno").on('click', function () {
            dialog.modal('hide');
            noCallback();
        });
    }
    dialog.modal('show').on('hidden.bs.modal', function () {
        $(this).remove();
    });
}

Dialog.info = function (msg, title) {
    var template = '<div id="wkfsdialoginfo" class="modal fade" role="dialog">'
                        + '<div class="modal-dialog">'
                            + '<div class="modal-content">'
                                + '<div class="modal-header dialog-info-modal-header">'
                                    + '<button type="button" class="close" data-dismiss="modal">&times;</button>'
                                    + '<h4>' + (typeof title === 'undefined' ? 'Info' : title) + '</h4>'
                                + '</div>'
                                + '<div class="modal-body">'
                                    + '<p>' + (typeof msg === 'undefined' ? '' : msg) + '</p>'
                                + '</div>'
                                + '<div class="modal-footer">'
                                    + '<button type="button" id="btnwkfsdialoginfook" class="btn btn-info" data-dismiss="modal">OK</button>'
                                + '</div>'
                            + '</div>'
                        + '</div>'
                    + '</div>';

    $(template).appendTo(document.body);
    var dialog = $('#wkfsdialoginfo');
    dialog.modal('show').on('hidden.bs.modal', function () {
        $(this).remove();
    });
}